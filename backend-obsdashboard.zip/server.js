const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

// Enable CORS for requests from http://localhost:4200
app.use(cors({
  origin: 'http://localhost:4200'
}));

// Middleware to parse JSON
app.use(express.json());

// Generate mock data
const generateMockData = () => {
  const data = [];
  const activities = ['Login', 'Update Profile', 'Create Order', 'Delete Item', 'View Report'];
  const statuses = ['Success', 'Failed', 'Pending'];
  const users = ['John Doe', 'Jane Smith', 'Alice Johnson', 'Bob Wilson'];

  for (let i = 1; i <= 10000; i++) {
    data.push({
      stt: i,
      activity: activities[Math.floor(Math.random() * activities.length)],
      code: `CODE${String(i).padStart(4, '0')}`,
      name: `Item ${i}`,
      description: `Description for item ${i}`,
      user: users[Math.floor(Math.random() * users.length)],
      created_at: new Date(2025, 0, 1 + Math.floor(Math.random() * 365)).toISOString(),
      status: statuses[Math.floor(Math.random() * statuses.length)],
    });
  }
  return data;
};

const mockData = generateMockData();

// API endpoint to return all 2000 rows
app.get('/api/data', (req, res) => {
  res.json(mockData);
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});